import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MaterialModule } from '@angular/material';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { VirtualtourComponent } from './virtualtour/virtualtour.component';
import { StationService } from './station.service';

@NgModule({
  declarations: [
    AppComponent,
    VirtualtourComponent
  ],
  imports: [
    MaterialModule.forRoot(),
    RouterModule.forRoot([
      {
        path:'tour',
        component:VirtualtourComponent
      },
      {
        path:'',
        pathMatch:'full',
        redirectTo:'/tour'
      }
    ]),
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [StationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
